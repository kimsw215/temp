/*
  Copyright 2019 Kakao Corp.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
@file:JvmName("AuthApiClientKt")

package com.kakao.sdk.auth

import com.kakao.sdk.auth.model.CertTokenInfo
import com.kakao.sdk.auth.model.OAuthToken
import com.kakao.sdk.common.model.ClientError
import com.kakao.sdk.common.model.ClientErrorCause
import io.reactivex.Single

class RxAuthApiClient(
    private val manager: RxAuthApiManager = RxAuthApiManager.instance,
    /** @suppress */ val tokenManagerProvider: TokenManagerProvider = TokenManagerProvider.instance
) {

    /**
     * 사용자 인증코드를 이용하여 신규 토큰 발급을 요청합니다.
     *
     * @param code 사용자 인증 코드
     * @param codeVerifier 사용자 인증 코드 verifier
     */
    fun issueAccessToken(
        code: String,
        codeVerifier: String? = null
    ): Single<OAuthToken> = manager.issueAccessToken(code, codeVerifier)


    /**
     * @suppress
     */
    fun issueAccessTokenWithCert(
        code: String,
        codeVerifier: String? = null
    ): Single<CertTokenInfo> = manager.issueAccessTokenWithCert(code, codeVerifier)

    @Deprecated("이 메서드는 더 이상 사용되지 않으므로 refreshToken()을 사용합니다.")
    @JvmOverloads
    fun refreshAccessToken(
        oldToken: OAuthToken = tokenManagerProvider.manager.getToken() ?: throw ClientError(ClientErrorCause.TokenNotFound, "Refresh token not found. You must login first.")
    ): Single<OAuthToken> = manager.refreshToken(oldToken)

    /**
     * 기존 토큰을 갱신합니다
     *
     * @param oldToken 기존 토큰
     */
    @JvmOverloads
    fun refreshToken(
        oldToken: OAuthToken = tokenManagerProvider.manager.getToken() ?: throw ClientError(ClientErrorCause.TokenNotFound, "Refresh token not found. You must login first.")
    ): Single<OAuthToken> = manager.refreshToken(oldToken)


    /**
     * @suppress
     */
    fun agt(): Single<String> = manager.agt()

    companion object {
        @JvmStatic
        val instance by lazy { AuthApiClient.rx }
    }
}

val AuthApiClient.Companion.rx by lazy { RxAuthApiClient() }