package com.kakao.sdk.auth

import com.kakao.sdk.auth.model.CertTokenInfo
import com.kakao.sdk.auth.model.OAuthToken
import com.kakao.sdk.auth.network.rxKauth
import com.kakao.sdk.common.KakaoSdk
import com.kakao.sdk.common.model.*
import com.kakao.sdk.common.util.SdkLog
import com.kakao.sdk.network.ApiFactory
import io.reactivex.Single
import io.reactivex.SingleTransformer

/**
 * @suppress
 */
class RxAuthApiManager(
    private val authApi: RxAuthApi = ApiFactory.rxKauth.create(RxAuthApi::class.java),
    /** @suppress */ val tokenManagerProvider: TokenManagerProvider = TokenManagerProvider.instance,
    /** @suppress */ val applicationInfo: ApplicationInfo = KakaoSdk.applicationContextInfo,
    /** @suppress */ val contextInfo: ContextInfo = KakaoSdk.applicationContextInfo,
    /** @suppress */ val approvalType: ApprovalType = KakaoSdk.approvalType
) {

    /**
     * @suppress
     */
    internal fun issueAccessToken(
        code: String,
        codeVerifier: String? = null
    ): Single<OAuthToken> =
        authApi.issueAccessToken(
            clientId = applicationInfo.appKey,
            androidKeyHash = contextInfo.signingKeyHash,
            code = code,
            redirectUri = applicationInfo.redirectUri,
            codeVerifier = codeVerifier,
            approvalType = approvalType.value
        )
            .compose(handleAuthError())
            .map { OAuthToken.fromResponse(it) }
            .doOnSuccess { tokenManagerProvider.manager.setToken(it) }

    /**
     * @suppress
     */
    internal fun issueAccessTokenWithCert(
        code: String,
        codeVerifier: String? = null
    ): Single<CertTokenInfo> =
        authApi.issueAccessToken(
            clientId = applicationInfo.appKey,
            androidKeyHash = contextInfo.signingKeyHash,
            code = code,
            redirectUri = applicationInfo.redirectUri,
            codeVerifier = codeVerifier,
            approvalType = approvalType.value
        )
            .compose(handleAuthError())
            .map {
                if (it.txId.isNullOrEmpty()) {
                    throw ClientError(
                        ClientErrorCause.Unknown,
                        "txId is null"
                    )
                }
                else {
                    CertTokenInfo(OAuthToken.fromResponse(it), it.txId!!)
                }
            }
            .doOnSuccess { tokenManagerProvider.manager.setToken(it.token) }
    /**
     * @suppress
     */
    @JvmOverloads
    internal fun refreshToken(
        oldToken: OAuthToken = tokenManagerProvider.manager.getToken() ?: throw ClientError(
            ClientErrorCause.TokenNotFound, "Refresh token not found. You must login first.")
    ): Single<OAuthToken> =
        authApi.refreshToken(
            clientId = applicationInfo.appKey,
            androidKeyHash = contextInfo.signingKeyHash,
            refreshToken = oldToken.refreshToken,
            approvalType = approvalType.value
        )
            .compose(handleAuthError())
            .map { OAuthToken.fromResponse(it, oldToken) }
            .doOnSuccess { tokenManagerProvider.manager.setToken(it) }


    /**
     * @suppress
     */
    internal fun agt(): Single<String> =
        Single.just(tokenManagerProvider.manager.getToken()?.accessToken)
            .flatMap { authApi.agt(clientId = KakaoSdk.applicationContextInfo.appKey, accessToken = it) }
            .compose(handleAuthError())
            .map { it.agt }


    companion object {
        @JvmStatic
        val instance by lazy { AuthApiManager.rx }

        fun <T> handleAuthError(): SingleTransformer<T, T> = SingleTransformer {
            it.onErrorResumeNext { Single.error(AuthApiManager.translateError(it)) }
                .doOnError { SdkLog.e(it) }
                .doOnSuccess { SdkLog.i(it!!) }
        }
    }
}

val AuthApiManager.Companion.rx by lazy { RxAuthApiManager() }