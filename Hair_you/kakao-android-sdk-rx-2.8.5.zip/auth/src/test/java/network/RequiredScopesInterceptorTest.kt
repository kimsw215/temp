/*
  Copyright 2021 Kakao Corp.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package com.kakao.sdk.auth.network

import com.kakao.sdk.common.model.ApiError
import com.kakao.sdk.common.model.ApplicationContextInfo
import com.kakao.sdk.common.util.Utility
import com.kakao.sdk.network.ExceptionWrapper
import com.kakao.sdk.network.origin
import junit.framework.Assert.assertTrue
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.mockito.Mockito
import org.mockito.Mockito.anyString

class RequiredScopesInterceptorTest {
    private lateinit var server: MockWebServer
    private lateinit var client: OkHttpClient
    private lateinit var requiredScopesInterceptor: RequiredScopesInterceptor

    @BeforeEach
    fun setup() {
        server = MockWebServer()

        val applicationContextInfo = Mockito.mock(ApplicationContextInfo::class.java)
        Mockito.`when`(applicationContextInfo.kaHeader).thenReturn(anyString())

        requiredScopesInterceptor = RequiredScopesInterceptor(applicationContextInfo)
        client = OkHttpClient().newBuilder().addInterceptor(requiredScopesInterceptor).build()
    }

    /**
     * -402 에러이면서 requiredScopes가 empty or null 일 때 에러처리 테스트
     */
    @Test
    fun testFriends() {
        val body = Utility.getJson("json/friends/friends.json")

        server.setDispatcher(object : Dispatcher() {
            override fun dispatch(request: RecordedRequest): MockResponse {
                return when (request.path) {
                    "/v1/api/talk/friends" -> MockResponse().setResponseCode(403)
                        .setBody("{\"msg\":\"insufficient scopes.\",\"code\":-402,\"api_type\":\"FRIENDS\",\"required_scopes\":[],\"allowed_scopes\":[\"profile\"]}")
                    else -> MockResponse().setResponseCode(200).setBody(body)
                }
            }
        })
        
        try {
            client.newCall(Request.Builder().url(server.url("/v1/api/talk/friends")).build()).execute()
        } catch(e: Exception) {
            assertTrue(e is ExceptionWrapper)
            assertTrue(e.origin is ApiError)
        }
    }

    @AfterEach
    fun tearDown() {
        server.shutdown()
    }
}